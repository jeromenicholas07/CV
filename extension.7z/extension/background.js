  var ruleList = [];
  var ruleStatus = {};
  var statusStreamPort = undefined;
  
chrome.storage.sync.get('rules', function(ruleData){
	ruleList = (ruleData.rules)? ruleData.rules :[];
});
  
  
	chrome.runtime.onConnect.addListener(port => {
        console.log('connected ', port);

        if (port.name === 'rule-live-stream') {
            port.onMessage.addListener(function(sRule) {
				for(let index in ruleList){
					let rule = ruleList[index];
					
					if(rule.id === sRule.id){
						if(ruleStatus[rule.id]){
								ruleStatus[rule.id].currValue = sRule.value;
								ruleStatus[rule.id].lastUpdated = (new Date()).getTime();
								ruleStatus[rule.id].isDisabled = sRule.isDisabled;
								ruleStatus[rule.id].marketNotFound = sRule.marketNotFound;	
						}
						else{
							ruleStatus[rule.id] = {
								currValue: sRule.value,
								lastUpdated: (new Date()).getTime(),
								isDisabled: sRule.isDisabled,
								marketNotFound: sRule.marketNotFound
							};
						}
					}
				}
			});
        }
		if(port.name === 'rule-status-stream'){
			statusStreamPort = port;
			statusStreamPort.onDisconnect.addListener(port => {
				if(port.name === 'rule-status-stream'){
					statusStreamPort = undefined;
				}
			});
		}
	});
	

	chrome.storage.onChanged.addListener(function(changes, namespace) {
        for (let key in changes) {
			if(key === 'rules'){
				ruleList = changes[key].newValue;
			}
		}
    });
	
	chrome.runtime.onMessage.addListener(
	    function(msg, sender, sendResponse) {
			if ((msg.from === 'content') && (msg.subject === 'get-tab-id')) {
				sendResponse({tabId: sender.tab.id});
			}
	});
	
	async function updateStatus(){
		for(let i in ruleList){
			let rule = ruleList[i];
			console.log("rule stat:" + JSON.stringify(ruleStatus));
			let currentStatus = ruleStatus[rule.id]
			if(currentStatus){
				chrome.tabs.get(rule.tabId, function(tabInfo){
					if(!chrome.runtime.lastError || tabInfo){
						if(tabInfo.url == rule.url){
							if(currentStatus.marketNotFound){
								currentStatus.status = "Market not found";
							}
							else if(currentStatus.isDisabled){
								currentStatus.status = "Bet disabled";
							}
							else{
								let msSinceUpdate = (new Date()).getTime() - currentStatus.lastUpdated;
								if(msSinceUpdate <= 20000){
									if(currentStatus.currValue){
										currentStatus.status = "Active";
									}
									else{
										currentStatus.status = "Unable to read value";
									}
								}
								else{
									currentStatus.status = "Rule disconnected";
								}
							}
						}
						else{
							currentStatus.status = "URL changed";
						}
					}
					else{
						currentStatus.status = "Tab not found";
					}
				});
			}
			else{
				ruleStatus[rule.id] = {
					status: "Rule Inactive"
				};
			}
		}
		
		if(statusStreamPort){
			statusStreamPort.postMessage(ruleStatus);
		}
	}
	
	
	
	//async loop - status updates
	let run = async ()=>{
		await delay(5000);
		while(true){
			console.log("aye");
			await updateStatus();
			await delay(100);
		}
	}
	run();

	async function delay(ms) {
	  return await new Promise(resolve => setTimeout(resolve, ms));
	}