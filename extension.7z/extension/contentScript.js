var port = chrome.runtime.connect({name: "rule-live-stream"});
var ruleList = [];
var ruleStatus = {};
var ruleRefs = {};
var tabId = "-1";
var ongoingBet = false;
console.log("cs connected");

chrome.runtime.sendMessage({from:"content", subject: "get-tab-id"}, function(response) {
	tabId = response.tabId;
	chrome.storage.sync.get('rules', function(rulesData){
		let rules = (rulesData.rules)? rulesData.rules :[];
		ruleList = rules.filter(function(ele){ return ele.tabId ==  tabId;});
	});
});

chrome.storage.onChanged.addListener(function(changes, namespace) {
	for (let key in changes) {
		if(key === 'rules'){
			let rules = changes[key].newValue;
			rules = rules.filter(function(ele){ return ele.tabId ==  tabId; });
			if(JSON.stringify(ruleList) != JSON.stringify(rules)){
				ruleList = rules;
			}
		}
	}
});

async function observeRules(){
	let eventList = document.querySelectorAll('div.event-name');
	if(eventList.length == 0){
		//alert('Invalid page - xxx');
		return;
	}
	let marketList = [];
	for(let i = 0; i < eventList.length; i++){
		let marketTitle = "";
		if(eventList[i].closest('table').querySelector('.market-name.title>span')){
			marketTitle = eventList[i].closest('table').querySelector('.market-name.title>span').textContent.trim();
		}
		marketList.push({
			element: eventList[i],
			name: eventList[i].textContent.trim(),
			title: marketTitle
			});
	}
	for(let i in ruleList){
		let rule = ruleList[i];
		let notFound = true;
		let isDisabled = false;
		let oddValue = undefined;
		
		for(let j in marketList){
			let market = marketList[j];
			
			if(rule.marketName == market.name){
				console.log("obs:'" + market.title +"'.");
			}
			if( (rule.marketName == market.name)
				&& (rule.marketTitle == market.title) ){
					if(row = market.element.closest('tr')){	
						notFound = false;
						if(valueTD = row.querySelector('td.'+ rule.side +':not(.unhighlighted)')){
							if(valueEle = valueTD.querySelector('strong.odds')){
								oddValue = valueEle.textContent.trim();
								
								if(valueTD.classList.contains('betting-disabled')){
									isDisabled = true;
								}
								else{
									if(!ruleStatus[rule.id]){
										switch(rule.condition){
											case "greater":
												if(oddValue >= rule.threshold){
													ruleStatus[rule.id] = {
														startTime: (new Date()).getTime(),
														betNow: false
													};
												}
											break;
											case "lesser":
												if(oddValue <= rule.threshold){
													ruleStatus[rule.id] = {
														startTime: (new Date()).getTime(),
														betNow: false
													};
												}
											break;
										}
									}
									else{
										if(ruleStatus[rule.id].done){
											break;
										}
										if( (ruleStatus[rule.id].startTime + (parseInt(rule.delay)*1000)) <= (new Date()).getTime() ){
											
											switch(rule.condition){
												case "greater":
													if(oddValue >= rule.threshold){
														ongoingBet = true;
														ruleStatus[rule.id].betNow = true;
														let itr = 1;
														do{
															valueEle.click();
															await delay(1000);
															if(document.querySelectorAll('div.bet').length == 1){
																if(betCard = document.querySelector('div.bet')){
																	if(amountInput = betCard.querySelector('input.-qa-bet-stake-input')){
																		let changeEvent = new Event('change');
																		amountInput.value = rule.amount;
																		amountInput.dispatchEvent(changeEvent);
																		await delay(1000);
																		if(placeBetsButt = document.querySelector('.summary-buttons > .apl-btn-primary')){
																			if(!placeBetsButt.disabled){
																				if(document.querySelectorAll('div.bet').length == 1){
																					console.log("placing bet");
																					ruleStatus[rule.id].done = true;
																				}
																				else{
																					console.log("Other bets interfering in last operation");
																				}
																			}
																			else{
																				console.log("Place bets button disabled");
																			}
																		}
																		else{
																			console.log("Place bets button not found");
																		}
																	}
																	else{
																		console.log("unable to find amount field");
																	}
																}
																else{
																	console.log("unable to find bet card");
																}
																break;
															}
															else if(rmButt = document.querySelector('.summary-buttons > .apl-btn-remove:not(.apl-btn-mini)')){
																rmButt.click();
																console.log('Other bets interfering');
															}
															await delay(1000);
														}while(itr++ < 3);
														ongoingBet = false;
													}
													else{
														delete ruleStatus[rule.id];
													}
												break;
												case "lesser":
													if(oddValue <= rule.threshold){
														ruleStatus[rule.id].betNow = true;
													}
													else{
														delete ruleStatus[rule.id];
													}
												break;
											}
										}
									}
									
									//valueEle.click();
									
								}
								
								break;
							}
							else{
								isDisabled = true;
							}
						}
						else{
							isDisabled = true;
						}
					}
				}
		}
		
		port.postMessage({
			id: rule.id,
			value: oddValue,
			isDisabled: isDisabled,
			marketNotFound: notFound
		});
	}
}

// Listen for messages from the popup.
chrome.runtime.onMessage.addListener((msg, sender, response) => {
	if ((msg.from === 'popup') && (msg.subject === 'market-list')) {
		let eventList = document.querySelectorAll('div.event-name');
		
		if(eventList.length == 0){
			response(undefined);
			return;
		}
		
		let matchName = document.querySelector('div.header > h1').textContent.trim();
		let marketList = [];
		for(let i = 0; i < eventList.length; i++){
			let marketTitle = "";
			if(eventList[i].closest('table').querySelector('.market-name.title>span')){
				marketTitle = eventList[i].closest('table').querySelector('.market-name.title>span').textContent.trim();
			}
			marketList.push({
				name: eventList[i].textContent.trim(),
				title: marketTitle
				});
		}
		marketInfo = {
			from: 'content',
			subject: 'market-list',
			message: marketList,
			matchName: matchName
		}
		
		response(marketInfo);
	}
	
	if ((msg.from === 'popup') && (msg.subject === 'new-rule')) {
		
	}
});

let run = async ()=>{
	await delay(2000);
	while(true){
		await observeRules();
		await delay(100);
	}
}
run();

let keepActive = async ()=>{
	await delay(10000);
	while(true){
		if(!ongoingBet && (anyBet = document.querySelector('td.back:not(.unhighlighted)')) ){
			ongoingBet = true;
			anyBet.click();
			await delay(1000);
			if(rmButt = document.querySelector('.summary-buttons > .apl-btn-remove:not(.apl-btn-mini)')){
				rmButt.click();
			}
			else{
				await delay(2000);
				if(rmButt = document.querySelector('.summary-buttons > .apl-btn-remove:not(.apl-btn-mini)')){
					rmButt.click();
				}
				else{
					console.log("Keep page active function failed!!!");
				}
			}
			
			ongoingBet = false;
		}
		
		await delay(60000);
	}
}
keepActive();

async function delay(ms) {
  return await new Promise(resolve => setTimeout(resolve, ms));
}