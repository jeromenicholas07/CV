	document.addEventListener('DOMContentLoaded', function(){
		chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
			chrome.tabs.sendMessage(tabs[0].id, {from: "popup", subject: "market-list"}, function(response) {
				if(chrome.runtime.lastError || !response){
					return;
				}
				document.querySelector("#match-name").value = response.matchName;
				document.querySelector("#add-rule-card").style.display = "block";
				document.querySelector("#invalid-page-alert").style.display = "none";
				var marketDropdown = document.getElementById('market-dropdown');
				for(i = 0; i < response.message.length; i++){
					var marketName = response.message[i].name;
					var marketTitle = response.message[i].title;
					
					var opt = document.createElement("option");
					opt.textContent = marketName + (marketTitle ? " ("+marketTitle+")":"" );
					opt.value = marketName + ":::" + marketTitle;
					marketDropdown.appendChild(opt);
				}
			});
		});
	});
	
	var addRuleBtn = document.getElementById('add-rule-btn');
	addRuleBtn.addEventListener('click', function(eve){
		eve.preventDefault();
		var ruleForm = document.getElementById("rule-form");
		if (ruleForm.checkValidity()) {
			var newRule = {};
			data = $(ruleForm).serializeArray();
			
			for(i = 0; i < data.length; i++){
				switch(data[i].name){
					case "market-dropdown":
						newRule.marketName = data[i].value.split(':::')[0];
						newRule.marketTitle = data[i].value.split(':::')[1];
					break;
					case "back-or-lay-dropdown":
						newRule.side = data[i].value;
					break;
					case "delay-dropdown":
						newRule.delay = data[i].value;
					break;
					case "condition-dropdown":
						newRule.condition = data[i].value;
					break;
					case "threshold":
						newRule.threshold = data[i].value;
					break;
					case "amount":
						newRule.amount = data[i].value;
					break;
					case "match-name":
						newRule.matchName = data[i].value;
					break;
					
				}
			}
			
			chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
				chrome.storage.sync.get('rules', function(rulesData){
						var rules = (rulesData.rules)? rulesData.rules :[];
						
						newRule.tabId = tabs[0].id;
						if(tabs[0].url === ""){
							alert("Invalid page status");
						}
						newRule.url = tabs[0].url;
						newRule.id = (new Date()).getTime();
						
						rules.push(newRule);
						chrome.storage.sync.set({rules : rules}, function(){
							alert(JSON.stringify(newRule));
						});
				});
				
			});
		}
		else{
			ruleForm.reportValidity();
		}
	});