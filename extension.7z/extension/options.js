  var siteContainer = document.getElementById('site-container');
  var addSiteBtn = document.getElementById('add-site-button');
  
  var ruleListContainer = document.getElementById('rule-list');
  
  /*addSiteBtn.addEventListener('click', function() {
	  let newSite = document.getElementById('new-site').value.trim();
	  
	  chrome.storage.sync.get('sites', function(data) {
		if(data.sites === undefined){
			let siteList = [newSite];
			chrome.storage.sync.set({sites : siteList}, function(){
				$(siteContainer).children('.card').not('.add-site-card').remove();
				
				$('.add-site-card').before(newSiteCard(newSite));
			});
		}
		else{
			let siteList = data.sites;
			siteList.push(newSite);
			chrome.storage.sync.set({sites : siteList}, function(){
				var div = document.createElement("div");
				div.class = "card";
				
				$('.add-site-card').before(newSiteCard(newSite));
			});
		}
		
		document.getElementById('new-site').value = "";
	  });
  });*/
  
  function newSiteCard(siteName){
	  return '<div class="card"><div class="card-body">'+ siteName +' <span class="del-site" type="button">&#10006;</span></div></div>'
  }
  
  document.addEventListener('DOMContentLoaded', function(){
	  /*chrome.storage.sync.get('sites', function(data) {
		if(data.sites !== undefined){
			let siteList = data.sites;
			siteList.forEach(function(item, index){
				$('.add-site-card').before(newSiteCard(item));
			});
		}
	  });*/
  });
  
	document.addEventListener('click', function(event){
		/*if(event.target.matches('span.del-site')){
			let delSite = event.target.parentNode.textContent.split(' ')[0];
			var toDelete = confirm('Do you really want to remove \"' + delSite + '\"?');
			if(toDelete){
				chrome.storage.sync.get('sites' , function(data){
					let siteList = data.sites;
					siteList = siteList.filter(function(ele){return ele != delSite});
					chrome.storage.sync.set({sites : siteList}, function(){
						location.reload();
					});
				});
			}
			
		}*/
		if(event.target.matches('span.delete-rule')){
			var row = $(event.target).parents('tr');
			var ruleId = row.children('div.rule-id').text();
			
			var toDelete = confirm('Do you really want to delete this rule?');
			if(toDelete){
				chrome.storage.sync.get('rules' , function(data){
					let rList = data.rules;
					rList = rList.filter(function(ele){return ele.id != ruleId});
					chrome.storage.sync.set({rules : rList}, function(){
						location.reload();
					});
				});
			}
			
		}
	});
	
	chrome.storage.sync.get('rules', function(rulesData){
		let rules = (rulesData.rules)? rulesData.rules :[];
		
		for(var ind in rules){
			let rule = rules[ind];
			let row = document.createElement("tr");
			row.setAttribute('id', rule.id);
			
			var idDiv = document.createElement('div');
			idDiv.setAttribute('class', 'rule-id');
			idDiv.setAttribute('style', 'display: none;');
				idDiv.appendChild(document.createTextNode(rule.id));
			row.appendChild(idDiv);
			
			var th = document.createElement("th");
				let aa = document.createElement("a");
					aa.setAttribute('href', rule.url);
					aa.appendChild(document.createTextNode(rule.matchName));
				th.appendChild(aa);
			row.appendChild(th);
			
			var th = document.createElement("th");
				th.appendChild(document.createTextNode(rule.marketName));
			row.appendChild(th);
			
			td = document.createElement('td');
				td.appendChild(document.createTextNode(rule.marketTitle));
			row.appendChild(td);
			
			td = document.createElement('td');
				td.appendChild(document.createTextNode(rule.side));
			row.appendChild(td);
			
			td = document.createElement('td');
				td.appendChild(document.createTextNode(rule.delay));
			row.appendChild(td);
			
			td = document.createElement('td');
				td.appendChild(document.createTextNode(
					rule.condition + " than " + rule.threshold
				));
			row.appendChild(td);
			
			td = document.createElement('td');
			td.className = rule.side + " live-value";
				td.appendChild(document.createTextNode(""));
			row.appendChild(td);
			
			td = document.createElement('td');
			td.className = "last-updated";
			td.dataset.utime = 0;
				td.appendChild(document.createTextNode(""));
			row.appendChild(td);
			
			td = document.createElement('td');
			td.className = "status";
				td.appendChild(document.createTextNode(""));
			row.appendChild(td);
			
			td = document.createElement('td');
				var delBtn = document.createElement('span');
				delBtn.setAttribute("class","delete-rule");
				delBtn.setAttribute("type","button");
					delBtn.appendChild(document.createTextNode(' \u2716'));
				td.appendChild(delBtn);
			row.appendChild(td);
			
			ruleListContainer.appendChild(row);
		}
	});

	chrome.storage.onChanged.addListener(function(changes, namespace) {
        for (var key in changes) {
			if(key === "rules"){
				location.reload();
			}
        }
      });





	var port = chrome.runtime.connect({name: "rule-status-stream"});
	port.onMessage.addListener(function(ruleStatus) {
		console.log('listening');
		for(ruleId in ruleStatus){
			ruleInfo = ruleStatus[ruleId];
			if(row = ruleListContainer.querySelector('tr[id="'+ ruleId + '"]')){
				let valueTD = row.querySelector('.live-value');
				let lastUpdatedTD = row.querySelector('.last-updated');
				let statusTD = row.querySelector('.status');
				
				valueTD.textContent = ruleInfo.currValue;
				lastUpdatedTD.dataset.utime = ruleInfo.lastUpdated ? ruleInfo.lastUpdated:0;
				statusTD.textContent = ruleInfo.status;
			}
		}
	});
	
	function timeSince(date) {
		if(date == 0){
			return "--";
		}

	  var seconds = Math.floor((new Date() - date) / 1000);

	  var interval = Math.floor(seconds / 31536000);

	  if (interval > 1) {
		return interval + " years";
	  }
	  interval = Math.floor(seconds / 2592000);
	  if (interval > 1) {
		return interval + " months";
	  }
	  interval = Math.floor(seconds / 86400);
	  if (interval > 1) {
		return interval + " days";
	  }
	  interval = Math.floor(seconds / 3600);
	  if (interval > 1) {
		return interval + " hours";
	  }
	  interval = Math.floor(seconds / 60);
	  if (interval > 1) {
		return interval + " minutes";
	  }
	  return Math.floor(seconds) + " seconds";
	}
	
	let run = async ()=>{
		while(true){
			let lutTDs = document.getElementsByClassName('last-updated');
			for(let ele of lutTDs){
				ele.textContent = timeSince(ele.dataset.utime);
			}
			await delay(100);
		}
	}
	run();

	async function delay(ms) {
	  return await new Promise(resolve => setTimeout(resolve, ms));
	}
	